package fr.uranium.factions;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class FactionCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = Arrays.asList(
            "menu", "create", "disband", "invite", "join", "leave", "kick", "promote", "demote",
            "claim", "unclaim", "sethome", "home", "deposit", "withdraw", "top", "info", "help");

    private final UraniumFactions plugin;
    private final FactionManager fm;

    public FactionCommand(UraniumFactions plugin) {
        this.plugin = plugin;
        this.fm = plugin.manager();
    }

    private void msg(Player p, String s) {
        p.sendMessage(Text.c(UraniumFactions.PREFIX + s));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length == 0) {
            plugin.gui().openMain(p);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        Faction f = fm.getByPlayer(p.getUniqueId());

        switch (sub) {
            case "menu" -> plugin.gui().openMain(p);
            case "help" -> help(p);
            case "top" -> plugin.gui().openTop(p);
            case "create" -> create(p, f, args);
            case "join" -> join(p, f, args);
            case "info" -> info(p, f, args);
            default -> {
                if (f == null) {
                    msg(p, "&cTu n'as pas de faction. Utilise &f/f create <nom>&c.");
                    return true;
                }
                switch (sub) {
                    case "disband" -> disband(p, f);
                    case "leave" -> leave(p, f);
                    case "invite" -> invite(p, f, args);
                    case "kick" -> kick(p, f, args);
                    case "promote" -> setRole(p, f, args, true);
                    case "demote" -> setRole(p, f, args, false);
                    case "claim" -> claim(p, f);
                    case "unclaim" -> unclaim(p, f);
                    case "sethome" -> sethome(p, f);
                    case "home" -> home(p, f);
                    case "deposit" -> deposit(p, f, args);
                    case "withdraw" -> withdraw(p, f, args);
                    default -> help(p);
                }
            }
        }
        return true;
    }

    private void help(Player p) {
        msg(p, "&aCommandes :");
        p.sendMessage(Text.c("&8- &f/f &7menu GUI"));
        p.sendMessage(Text.c("&8- &f/f create|disband|leave &7gestion"));
        p.sendMessage(Text.c("&8- &f/f invite|join|kick|promote|demote &7membres"));
        p.sendMessage(Text.c("&8- &f/f claim|unclaim|sethome|home &7territoire"));
        p.sendMessage(Text.c("&8- &f/f deposit|withdraw <montant> &7banque"));
        p.sendMessage(Text.c("&8- &f/f top|info [faction] &7classement et infos"));
    }

    private void create(Player p, Faction f, String[] args) {
        if (f != null) { msg(p, "&cTu es deja dans une faction."); return; }
        if (args.length < 2) { msg(p, "&cUsage : /f create <nom>"); return; }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_]{3,12}")) {
            msg(p, "&cNom invalide (3 a 12 caracteres : lettres, chiffres, _).");
            return;
        }
        if (fm.getByName(name) != null) { msg(p, "&cCe nom est deja pris."); return; }
        Faction nf = fm.create(name, p.getUniqueId());
        Bukkit.broadcast(Text.c(UraniumFactions.PREFIX + "&aLa faction &f" + nf.getName() + " &aa ete creee par &f" + p.getName() + "&a !"));
    }

    private void disband(Player p, Faction f) {
        if (f.getRole(p.getUniqueId()) != Faction.Role.LEADER) { msg(p, "&cSeul le chef peut dissoudre la faction."); return; }
        String name = f.getName();
        fm.disband(f);
        Bukkit.broadcast(Text.c(UraniumFactions.PREFIX + "&cLa faction &f" + name + " &cvient d'etre dissoute."));
    }

    private void join(Player p, Faction f, String[] args) {
        if (f != null) { msg(p, "&cTu es deja dans une faction."); return; }
        if (args.length < 2) { msg(p, "&cUsage : /f join <faction>"); return; }
        Faction target = fm.getByName(args[1]);
        if (target == null) { msg(p, "&cFaction introuvable."); return; }
        if (!target.getInvites().contains(p.getUniqueId())) { msg(p, "&cTu n'as pas ete invite dans cette faction."); return; }
        fm.addMember(target, p.getUniqueId());
        broadcast(target, "&f" + p.getName() + " &aa rejoint la faction !");
    }

    private void leave(Player p, Faction f) {
        if (f.getRole(p.getUniqueId()) == Faction.Role.LEADER) {
            msg(p, "&cTu es le chef : fais &f/f disband &cou passe le role a quelqu'un (/f promote).");
            return;
        }
        fm.removeMember(f, p.getUniqueId());
        msg(p, "&aTu as quitte la faction &f" + f.getName() + "&a.");
        broadcast(f, "&f" + p.getName() + " &ca quitte la faction.");
    }

    private void invite(Player p, Faction f, String[] args) {
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef."); return; }
        if (args.length < 2) { msg(p, "&cUsage : /f invite <joueur>"); return; }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) { msg(p, "&cJoueur hors ligne."); return; }
        if (fm.getByPlayer(t.getUniqueId()) != null) { msg(p, "&cCe joueur a deja une faction."); return; }
        f.getInvites().add(t.getUniqueId());
        msg(p, "&aInvitation envoyee a &f" + t.getName() + "&a.");
        msg(t, "&aTu as ete invite dans &f" + f.getName() + "&a. Fais &f/f join " + f.getName());
    }

    private void kick(Player p, Faction f, String[] args) {
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef."); return; }
        if (args.length < 2) { msg(p, "&cUsage : /f kick <joueur>"); return; }
        OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
        UUID id = t.getUniqueId();
        Faction.Role target = f.getRole(id);
        if (target == null) { msg(p, "&cCe joueur n'est pas dans ta faction."); return; }
        Faction.Role mine = f.getRole(p.getUniqueId());
        if (target == Faction.Role.LEADER || (target == Faction.Role.OFFICER && mine != Faction.Role.LEADER)) {
            msg(p, "&cTu ne peux pas expulser ce joueur.");
            return;
        }
        fm.removeMember(f, id);
        broadcast(f, "&f" + args[1] + " &ca ete expulse de la faction.");
        Player online = t.getPlayer();
        if (online != null) msg(online, "&cTu as ete expulse de la faction &f" + f.getName() + "&c.");
    }

    private void setRole(Player p, Faction f, String[] args, boolean promote) {
        if (f.getRole(p.getUniqueId()) != Faction.Role.LEADER) { msg(p, "&cSeul le chef peut gerer les roles."); return; }
        if (args.length < 2) { msg(p, "&cUsage : /f " + (promote ? "promote" : "demote") + " <joueur>"); return; }
        OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
        UUID id = t.getUniqueId();
        Faction.Role current = f.getRole(id);
        if (current == null) { msg(p, "&cCe joueur n'est pas dans ta faction."); return; }
        if (id.equals(p.getUniqueId())) { msg(p, "&cTu ne peux pas te modifier toi-meme."); return; }
        if (promote) {
            if (current == Faction.Role.MEMBER) {
                f.getMembers().put(id, Faction.Role.OFFICER);
                broadcast(f, "&f" + args[1] + " &aest maintenant officier.");
            } else {
                // Officier -> chef : transfert de leadership
                f.getMembers().put(id, Faction.Role.LEADER);
                f.getMembers().put(p.getUniqueId(), Faction.Role.OFFICER);
                broadcast(f, "&f" + args[1] + " &aest le nouveau chef de la faction.");
            }
        } else {
            if (current == Faction.Role.OFFICER) {
                f.getMembers().put(id, Faction.Role.MEMBER);
                broadcast(f, "&f" + args[1] + " &cn'est plus officier.");
            } else {
                msg(p, "&cCe joueur est deja simple membre.");
                return;
            }
        }
        fm.save();
    }

    private void claim(Player p, Faction f) {
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef."); return; }
        Location l = p.getLocation();
        Faction owner = fm.getOwner(l);
        if (owner != null) {
            msg(p, owner.equals(f) ? "&cCe chunk est deja a toi." : "&cCe chunk appartient a &f" + owner.getName() + "&c.");
            return;
        }
        if (fm.claimCount(f) >= fm.maxClaims(f)) {
            msg(p, "&cPas assez de puissance pour un claim de plus (&f" + String.format("%.1f", fm.factionPower(f)) + " &cpower).");
            return;
        }
        fm.claim(f, l.getChunk());
        msg(p, "&aChunk claim ! &7(" + fm.claimCount(f) + "/" + fm.maxClaims(f) + ")");
    }

    private void unclaim(Player p, Faction f) {
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef."); return; }
        Faction owner = fm.getOwner(p.getLocation());
        if (owner == null || !owner.equals(f)) { msg(p, "&cCe chunk n'appartient pas a ta faction."); return; }
        fm.unclaim(p.getLocation().getChunk());
        msg(p, "&aChunk unclaim.");
    }

    private void sethome(Player p, Faction f) {
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef."); return; }
        Faction owner = fm.getOwner(p.getLocation());
        if (owner == null || !owner.equals(f)) { msg(p, "&cLe home doit etre dans un de tes claims."); return; }
        f.setHome(p.getLocation());
        fm.save();
        msg(p, "&aHome de faction defini.");
    }

    private void home(Player p, Faction f) {
        Location home = f.getHome();
        if (home == null) { msg(p, "&cTa faction n'a pas de home."); return; }
        msg(p, "&aTeleportation dans 3 secondes...");
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) p.teleport(home);
        }, 60L);
    }

    private Double parseAmount(Player p, String[] args) {
        if (args.length < 2) { msg(p, "&cUsage : /f " + args[0] + " <montant>"); return null; }
        try {
            double a = Double.parseDouble(args[1]);
            if (a <= 0 || Double.isNaN(a) || Double.isInfinite(a)) throw new NumberFormatException();
            return a;
        } catch (NumberFormatException e) {
            msg(p, "&cMontant invalide.");
            return null;
        }
    }

    private void deposit(Player p, Faction f, String[] args) {
        Economy eco = plugin.economy();
        if (eco == null) { msg(p, "&cLa banque n'est pas disponible (pas d'economie)."); return; }
        Double amount = parseAmount(p, args);
        if (amount == null) return;
        if (!eco.has(p, amount)) { msg(p, "&cTu n'as pas assez d'argent."); return; }
        if (!eco.withdrawPlayer(p, amount).transactionSuccess()) { msg(p, "&cErreur de transaction."); return; }
        f.setBank(f.getBank() + amount);
        fm.save();
        broadcast(f, "&f" + p.getName() + " &aa depose &f" + Text.money(amount) + " &adans la banque.");
    }

    private void withdraw(Player p, Faction f, String[] args) {
        Economy eco = plugin.economy();
        if (eco == null) { msg(p, "&cLa banque n'est pas disponible (pas d'economie)."); return; }
        if (!f.isOfficerOrLeader(p.getUniqueId())) { msg(p, "&cIl faut etre officier ou chef pour retirer."); return; }
        Double amount = parseAmount(p, args);
        if (amount == null) return;
        if (f.getBank() < amount) { msg(p, "&cLa banque n'a pas assez d'argent."); return; }
        if (!eco.depositPlayer(p, amount).transactionSuccess()) { msg(p, "&cErreur de transaction."); return; }
        f.setBank(f.getBank() - amount);
        fm.save();
        broadcast(f, "&f" + p.getName() + " &ca retire &f" + Text.money(amount) + " &cde la banque.");
    }

    private void info(Player p, Faction mine, String[] args) {
        Faction f = args.length >= 2 ? fm.getByName(args[1]) : mine;
        if (f == null) {
            msg(p, args.length >= 2 ? "&cFaction introuvable." : "&cTu n'as pas de faction.");
            return;
        }
        UUID leader = f.getLeader();
        String leaderName = leader == null ? "?" : String.valueOf(Bukkit.getOfflinePlayer(leader).getName());
        p.sendMessage(Text.c("&8&m      &r &2&l" + f.getName() + " &8&m      "));
        p.sendMessage(Text.c("&aChef : &f" + leaderName));
        p.sendMessage(Text.c("&aPower : &f" + String.format("%.1f", fm.factionPower(f))
                + " &7| &aClaims : &f" + fm.claimCount(f) + "/" + fm.maxClaims(f)));
        p.sendMessage(Text.c("&aKills : &f" + f.getKills() + " &7| &aBanque : &f" + Text.money(f.getBank())));
        p.sendMessage(Text.c("&aStatut : " + (fm.isRaidable(f) ? "&cRaidable" : "&2Protegee")));
        StringBuilder sb = new StringBuilder();
        for (UUID m : f.getMembers().keySet()) {
            String n = Bukkit.getOfflinePlayer(m).getName();
            Faction.Role r = f.getRole(m);
            String prefix = r == Faction.Role.LEADER ? "**" : r == Faction.Role.OFFICER ? "*" : "";
            sb.append(prefix).append(n).append(", ");
        }
        if (sb.length() > 2) sb.setLength(sb.length() - 2);
        p.sendMessage(Text.c("&aMembres : &f" + sb));
    }

    private void broadcast(Faction f, String text) {
        for (UUID m : f.getMembers().keySet()) {
            Player pl = Bukkit.getPlayer(m);
            if (pl != null) msg(pl, text);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2) {
            String a = args[0].toLowerCase(Locale.ROOT);
            if (a.equals("join") || a.equals("info")) {
                for (Faction f : fm.all()) if (f.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(f.getName());
            } else if (a.equals("invite") || a.equals("kick") || a.equals("promote") || a.equals("demote")) {
                for (Player pl : Bukkit.getOnlinePlayers()) if (pl.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(pl.getName());
            }
        }
        return out;
    }
}
