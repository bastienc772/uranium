package fr.uranium.factions;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

public class FactionListener implements Listener {

    private final UraniumFactions plugin;
    private final FactionManager fm;

    public FactionListener(UraniumFactions plugin) {
        this.plugin = plugin;
        this.fm = plugin.manager();
    }

    /** Un joueur peut agir dans un claim s'il en est membre, si la faction est raidable, ou s'il a le bypass. */
    private boolean canBuild(Player p, Location loc) {
        Faction owner = fm.getOwner(loc);
        if (owner == null) return true;
        if (p.hasPermission("uraniumfactions.bypass")) return true;
        if (owner.getMembers().containsKey(p.getUniqueId())) return true;
        return fm.isRaidable(owner);
    }

    private void deny(Player p, Location loc) {
        Faction owner = fm.getOwner(loc);
        String name = owner == null ? "?" : owner.getName();
        p.sendMessage(Text.c(UraniumFactions.PREFIX + "&cCe territoire appartient a &f" + name + "&c."));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!canBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer(), e.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!canBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer(), e.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        if (!(b.getState() instanceof Container)) return;
        if (!canBuild(e.getPlayer(), b.getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer(), b.getLocation());
        }
    }

    /** Les explosions ne detruisent que les claims de factions raidables. */
    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> {
            Faction owner = fm.getOwner(b.getLocation());
            return owner != null && !fm.isRaidable(owner);
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim) || !(e.getDamager() instanceof Player damager)) return;
        Faction a = fm.getByPlayer(victim.getUniqueId());
        Faction b = fm.getByPlayer(damager.getUniqueId());
        if (a != null && a.equals(b)) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        fm.addPower(victim.getUniqueId(), -2.0);
        victim.sendMessage(Text.c(UraniumFactions.PREFIX + "&cTu perds &f2 power&c. Power : &f"
                + String.format("%.1f", fm.getPower(victim.getUniqueId()))));

        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;
        Faction kf = fm.getByPlayer(killer.getUniqueId());
        Faction vf = fm.getByPlayer(victim.getUniqueId());
        if (kf != null && kf.equals(vf)) return;
        fm.addPower(killer.getUniqueId(), 1.0);
        if (kf != null) {
            kf.setKills(kf.getKills() + 1);
            fm.save();
        }
        killer.sendMessage(Text.c(UraniumFactions.PREFIX + "&a+1 power pour ce kill."));
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if ((from.getBlockX() >> 4) == (to.getBlockX() >> 4) && (from.getBlockZ() >> 4) == (to.getBlockZ() >> 4)
                && from.getWorld().equals(to.getWorld())) return;

        Faction a = fm.getOwner(from);
        Faction b = fm.getOwner(to);
        if (a == b) return;
        Player p = e.getPlayer();
        if (b == null) {
            p.sendActionBar(Text.c("&7Zone libre"));
        } else {
            String state = fm.isRaidable(b) ? " &c(raidable)" : "";
            boolean own = b.getMembers().containsKey(p.getUniqueId());
            p.sendActionBar(Text.c((own ? "&a" : "&c") + "Territoire : &f" + b.getName() + state));
        }
    }
}
