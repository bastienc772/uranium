package fr.uranium.factions;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class UraniumFactions extends JavaPlugin {

    public static final String PREFIX = "&2&lURANIUM &8» &7";

    private FactionManager manager;
    private GuiManager gui;
    private Economy economy;

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        manager = new FactionManager(this);
        manager.load();
        setupEconomy();
        gui = new GuiManager(this);

        FactionCommand cmd = new FactionCommand(this);
        getCommand("f").setExecutor(cmd);
        getCommand("f").setTabCompleter(cmd);
        getCommand("fadmin").setExecutor(new AdminCommand(this));

        getServer().getPluginManager().registerEvents(new FactionListener(this), this);
        getServer().getPluginManager().registerEvents(gui, this);

        // Regeneration de la puissance toutes les 10 minutes + sauvegarde auto toutes les 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, manager::regenPower, 20L * 60 * 10, 20L * 60 * 10);
        Bukkit.getScheduler().runTaskTimer(this, manager::save, 20L * 60 * 5, 20L * 60 * 5);

        getLogger().info("UraniumFactions active.");
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.save();
    }

    private void setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            getLogger().warning("Vault introuvable : la banque de faction est desactivee.");
            return;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().warning("Aucun plugin d'economie trouve (ex: EssentialsX) : banque desactivee.");
            return;
        }
        economy = rsp.getProvider();
    }

    public FactionManager manager() { return manager; }
    public GuiManager gui() { return gui; }
    public Economy economy() { return economy; }
}
