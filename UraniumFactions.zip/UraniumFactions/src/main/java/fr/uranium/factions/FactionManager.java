package fr.uranium.factions;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class FactionManager {

    public static final double MAX_POWER = 10.0;
    public static final double MIN_POWER = -5.0;

    private final UraniumFactions plugin;
    private final Map<UUID, Faction> factions = new HashMap<>();
    private final Map<UUID, UUID> playerFaction = new HashMap<>();
    private final Map<String, UUID> claims = new HashMap<>();
    private final Map<UUID, Double> power = new HashMap<>();

    public FactionManager(UraniumFactions plugin) {
        this.plugin = plugin;
    }

    // ---------- Factions ----------

    public Faction getById(UUID id) { return factions.get(id); }

    public Faction getByPlayer(UUID player) {
        UUID id = playerFaction.get(player);
        return id == null ? null : factions.get(id);
    }

    public Faction getByName(String name) {
        for (Faction f : factions.values()) {
            if (f.getName().equalsIgnoreCase(name)) return f;
        }
        return null;
    }

    public List<Faction> all() { return new ArrayList<>(factions.values()); }

    public Faction create(String name, UUID leader) {
        Faction f = new Faction(UUID.randomUUID(), name);
        f.getMembers().put(leader, Faction.Role.LEADER);
        factions.put(f.getId(), f);
        playerFaction.put(leader, f.getId());
        save();
        return f;
    }

    public void disband(Faction f) {
        for (UUID member : f.getMembers().keySet()) playerFaction.remove(member);
        claims.values().removeIf(id -> id.equals(f.getId()));
        factions.remove(f.getId());
        save();
    }

    public void addMember(Faction f, UUID player) {
        f.getMembers().put(player, Faction.Role.MEMBER);
        f.getInvites().remove(player);
        playerFaction.put(player, f.getId());
        save();
    }

    public void removeMember(Faction f, UUID player) {
        f.getMembers().remove(player);
        playerFaction.remove(player);
        save();
    }

    // ---------- Claims ----------

    public String key(String world, int cx, int cz) {
        return world + ";" + cx + ";" + cz;
    }

    public String key(Chunk c) {
        return key(c.getWorld().getName(), c.getX(), c.getZ());
    }

    public String key(Location l) {
        return key(l.getWorld().getName(), l.getBlockX() >> 4, l.getBlockZ() >> 4);
    }

    public Faction getOwner(Location l) {
        UUID id = claims.get(key(l));
        return id == null ? null : factions.get(id);
    }

    public Faction getOwner(Chunk c) {
        UUID id = claims.get(key(c));
        return id == null ? null : factions.get(id);
    }

    public void claim(Faction f, Chunk c) {
        claims.put(key(c), f.getId());
        save();
    }

    public void unclaim(Chunk c) {
        claims.remove(key(c));
        save();
    }

    public int claimCount(Faction f) {
        int n = 0;
        for (UUID id : claims.values()) if (id.equals(f.getId())) n++;
        return n;
    }

    // ---------- Power ----------

    public double getPower(UUID player) {
        return power.getOrDefault(player, MAX_POWER);
    }

    public void setPower(UUID player, double value) {
        power.put(player, Math.max(MIN_POWER, Math.min(MAX_POWER, value)));
    }

    public void addPower(UUID player, double delta) {
        setPower(player, getPower(player) + delta);
    }

    public double factionPower(Faction f) {
        double total = 0;
        for (UUID m : f.getMembers().keySet()) total += getPower(m);
        return Math.max(0, total);
    }

    public int maxClaims(Faction f) {
        return (int) Math.floor(factionPower(f));
    }

    /** Une faction est "raidable" quand elle a plus de claims que sa puissance ne le permet. */
    public boolean isRaidable(Faction f) {
        return claimCount(f) > maxClaims(f);
    }

    public void regenPower() {
        for (UUID p : new ArrayList<>(playerFaction.keySet())) addPower(p, 0.5);
    }

    // ---------- Classement ----------

    public double score(Faction f) {
        return factionPower(f) * 10 + f.getKills() * 5 + claimCount(f) * 2 + f.getBank() / 1000.0;
    }

    public List<Faction> top() {
        List<Faction> list = all();
        list.sort(Comparator.comparingDouble(this::score).reversed());
        return list;
    }

    // ---------- Sauvegarde ----------

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Faction f : factions.values()) {
            String base = "factions." + f.getId();
            y.set(base + ".name", f.getName());
            y.set(base + ".bank", f.getBank());
            y.set(base + ".kills", f.getKills());
            if (f.getHome() != null) y.set(base + ".home", f.getHome());
            for (Map.Entry<UUID, Faction.Role> e : f.getMembers().entrySet()) {
                y.set(base + ".members." + e.getKey(), e.getValue().name());
            }
            List<String> owned = new ArrayList<>();
            for (Map.Entry<String, UUID> e : claims.entrySet()) {
                if (e.getValue().equals(f.getId())) owned.add(e.getKey());
            }
            y.set(base + ".claims", owned);
        }
        for (Map.Entry<UUID, Double> e : power.entrySet()) {
            y.set("power." + e.getKey(), e.getValue());
        }
        try {
            y.save(new File(plugin.getDataFolder(), "data.yml"));
        } catch (IOException ex) {
            plugin.getLogger().severe("Impossible de sauvegarder data.yml : " + ex.getMessage());
        }
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "data.yml");
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection fs = y.getConfigurationSection("factions");
        if (fs != null) {
            for (String key : fs.getKeys(false)) {
                ConfigurationSection s = fs.getConfigurationSection(key);
                if (s == null) continue;
                Faction f = new Faction(UUID.fromString(key), s.getString("name", "Inconnue"));
                f.setBank(s.getDouble("bank"));
                f.setKills(s.getInt("kills"));
                f.setHome(s.getLocation("home"));
                ConfigurationSection ms = s.getConfigurationSection("members");
                if (ms != null) {
                    for (String u : ms.getKeys(false)) {
                        UUID uid = UUID.fromString(u);
                        f.getMembers().put(uid, Faction.Role.valueOf(ms.getString(u, "MEMBER")));
                        playerFaction.put(uid, f.getId());
                    }
                }
                for (String c : s.getStringList("claims")) claims.put(c, f.getId());
                factions.put(f.getId(), f);
            }
        }

        ConfigurationSection ps = y.getConfigurationSection("power");
        if (ps != null) {
            for (String u : ps.getKeys(false)) power.put(UUID.fromString(u), ps.getDouble(u));
        }
    }
}
