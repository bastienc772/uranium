package fr.uranium.factions;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public class GuiManager implements Listener {

    public enum Type { MAIN, TOP }

    public static class Holder implements InventoryHolder {
        final Type type;
        Inventory inv;

        Holder(Type type) { this.type = type; }

        @Override
        public Inventory getInventory() { return inv; }
    }

    private static final int[] TOP_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};

    private final UraniumFactions plugin;

    public GuiManager(UraniumFactions plugin) {
        this.plugin = plugin;
    }

    private ItemStack filler() {
        return Text.item(Material.LIME_STAINED_GLASS_PANE, " ");
    }

    private void fill(Inventory inv) {
        ItemStack f = filler();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f);
    }

    /** Menu principal : l'argent du joueur est affiche dans le titre des l'ouverture. */
    public void openMain(Player p) {
        FactionManager fm = plugin.manager();
        Faction f = fm.getByPlayer(p.getUniqueId());
        Economy eco = plugin.economy();
        String balance = eco == null ? "" : " &8| &a" + Text.money(eco.getBalance(p));

        Holder h = new Holder(Type.MAIN);
        Inventory inv = Bukkit.createInventory(h, 27, Text.c("&2&lURANIUM" + balance));
        h.inv = inv;
        fill(inv);

        if (f == null) {
            inv.setItem(11, Text.item(Material.EMERALD, "&a&lCreer une faction",
                    "&7Utilise &f/f create <nom>"));
            inv.setItem(13, Text.item(Material.NETHER_STAR, "&a&lClassement des factions",
                    "&7Clique pour voir le top"));
            inv.setItem(15, Text.item(Material.BOOK, "&a&lAide", "&7Clique pour voir les commandes"));
        } else {
            inv.setItem(10, Text.item(Material.BOOK, "&a&lInfos de la faction",
                    "&7Power : &f" + String.format("%.1f", fm.factionPower(f)),
                    "&7Claims : &f" + fm.claimCount(f) + "/" + fm.maxClaims(f),
                    "&7Kills : &f" + f.getKills()));
            inv.setItem(11, Text.item(Material.GRASS_BLOCK, "&a&lClaim ce chunk",
                    "&7Officier ou chef uniquement"));
            inv.setItem(12, Text.item(Material.DIRT, "&c&lUnclaim ce chunk",
                    "&7Officier ou chef uniquement"));
            inv.setItem(13, Text.item(Material.RED_BED, "&a&lHome de faction",
                    "&7Clic gauche : &fse teleporter", "&7Clic droit : &fdefinir le home"));
            inv.setItem(14, Text.item(Material.GOLD_INGOT, "&6&lBanque : &f" + Text.money(f.getBank()),
                    "&7Clic gauche : &adeposer 100$", "&7Clic droit : &cretirer 100$",
                    "&7Shift + clic : &f1 000$"));
            inv.setItem(15, Text.item(Material.PLAYER_HEAD, "&a&lMembres",
                    "&7" + f.getMembers().size() + " membre(s)", "&7Clique pour la liste"));
            inv.setItem(16, Text.item(Material.NETHER_STAR, "&a&lClassement des factions",
                    "&7Clique pour voir le top"));
            inv.setItem(22, Text.item(Material.BARRIER, "&c&lQuitter la faction"));
        }
        p.openInventory(inv);
    }

    public void openTop(Player p) {
        FactionManager fm = plugin.manager();
        Holder h = new Holder(Type.TOP);
        Inventory inv = Bukkit.createInventory(h, 45, Text.c("&2&lTOP FACTIONS"));
        h.inv = inv;
        fill(inv);

        List<Faction> top = fm.top();
        for (int i = 0; i < TOP_SLOTS.length && i < top.size(); i++) {
            Faction f = top.get(i);
            Material m = switch (i) {
                case 0 -> Material.GOLD_BLOCK;
                case 1 -> Material.IRON_BLOCK;
                case 2 -> Material.COPPER_BLOCK;
                default -> Material.EMERALD_BLOCK;
            };
            UUID leader = f.getLeader();
            String leaderName = leader == null ? "?" : String.valueOf(Bukkit.getOfflinePlayer(leader).getName());
            inv.setItem(TOP_SLOTS[i], Text.item(m, "&a&l#" + (i + 1) + " &f" + f.getName(),
                    "&7Chef : &f" + leaderName,
                    "&7Membres : &f" + f.getMembers().size(),
                    "&7Power : &f" + String.format("%.1f", fm.factionPower(f)),
                    "&7Kills : &f" + f.getKills(),
                    "&7Claims : &f" + fm.claimCount(f),
                    "&7Banque : &f" + Text.money(f.getBank()),
                    "&8Score : " + String.format("%.0f", fm.score(f))));
        }
        inv.setItem(40, Text.item(Material.ARROW, "&a&lRetour"));
        p.openInventory(inv);
    }

    private void run(Player p, String command, boolean reopen) {
        p.performCommand(command);
        if (reopen) Bukkit.getScheduler().runTask(plugin, () -> openMain(p));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;

        int slot = e.getSlot();
        ClickType click = e.getClick();
        boolean right = click.isRightClick();
        boolean shift = click.isShiftClick();
        Faction f = plugin.manager().getByPlayer(p.getUniqueId());

        if (h.type == Type.TOP) {
            if (slot == 40) openMain(p);
            return;
        }

        if (f == null) {
            switch (slot) {
                case 11 -> { p.closeInventory(); p.sendMessage(Text.c(UraniumFactions.PREFIX + "&aUtilise &f/f create <nom>")); }
                case 13 -> openTop(p);
                case 15 -> { p.closeInventory(); p.performCommand("f help"); }
                default -> { }
            }
            return;
        }

        switch (slot) {
            case 10 -> { p.closeInventory(); p.performCommand("f info"); }
            case 11 -> run(p, "f claim", true);
            case 12 -> run(p, "f unclaim", true);
            case 13 -> {
                if (right) run(p, "f sethome", true);
                else { p.closeInventory(); p.performCommand("f home"); }
            }
            case 14 -> {
                String amount = shift ? "1000" : "100";
                run(p, (right ? "f withdraw " : "f deposit ") + amount, true);
            }
            case 15 -> { p.closeInventory(); p.performCommand("f info"); }
            case 16 -> openTop(p);
            case 22 -> { p.closeInventory(); p.performCommand("f leave"); }
            default -> { }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
