package fr.uranium.factions;

import org.bukkit.Location;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Faction {

    public enum Role { MEMBER, OFFICER, LEADER }

    private final UUID id;
    private String name;
    private final Map<UUID, Role> members = new LinkedHashMap<>();
    private final Set<UUID> invites = new HashSet<>();
    private double bank;
    private int kills;
    private Location home;

    public Faction(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public UUID getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Map<UUID, Role> getMembers() { return members; }
    public Set<UUID> getInvites() { return invites; }
    public double getBank() { return bank; }
    public void setBank(double bank) { this.bank = Math.max(0, bank); }
    public int getKills() { return kills; }
    public void setKills(int kills) { this.kills = kills; }
    public Location getHome() { return home; }
    public void setHome(Location home) { this.home = home; }

    public Role getRole(UUID uuid) { return members.get(uuid); }

    public boolean isOfficerOrLeader(UUID uuid) {
        Role r = members.get(uuid);
        return r == Role.OFFICER || r == Role.LEADER;
    }

    public UUID getLeader() {
        for (Map.Entry<UUID, Role> e : members.entrySet()) {
            if (e.getValue() == Role.LEADER) return e.getKey();
        }
        return null;
    }
}
