package fr.uranium.factions;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

public class AdminCommand implements CommandExecutor {

    private final FactionManager fm;

    public AdminCommand(UraniumFactions plugin) {
        this.fm = plugin.manager();
    }

    private void msg(CommandSender s, String text) {
        s.sendMessage(Text.c(UraniumFactions.PREFIX + text));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            msg(sender, "&aAdmin : &f/fadmin disband <faction> | setpower <joueur> <n> | setbank <faction> <n> | unclaim | forceclaim <faction>");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "disband" -> {
                if (args.length < 2) { msg(sender, "&cUsage : /fadmin disband <faction>"); return true; }
                Faction f = fm.getByName(args[1]);
                if (f == null) { msg(sender, "&cFaction introuvable."); return true; }
                fm.disband(f);
                msg(sender, "&aFaction &f" + f.getName() + " &adissoute.");
            }
            case "setpower" -> {
                if (args.length < 3) { msg(sender, "&cUsage : /fadmin setpower <joueur> <n>"); return true; }
                Double v = parse(args[2]);
                if (v == null) { msg(sender, "&cNombre invalide."); return true; }
                OfflinePlayer t = Bukkit.getOfflinePlayer(args[1]);
                fm.setPower(t.getUniqueId(), v);
                fm.save();
                msg(sender, "&aPower de &f" + args[1] + " &adefini a &f" + v + "&a.");
            }
            case "setbank" -> {
                if (args.length < 3) { msg(sender, "&cUsage : /fadmin setbank <faction> <n>"); return true; }
                Faction f = fm.getByName(args[1]);
                Double v = parse(args[2]);
                if (f == null || v == null) { msg(sender, "&cFaction ou nombre invalide."); return true; }
                f.setBank(v);
                fm.save();
                msg(sender, "&aBanque de &f" + f.getName() + " &adefinie a &f" + Text.money(f.getBank()) + "&a.");
            }
            case "unclaim" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cJoueur uniquement."); return true; }
                if (fm.getOwner(p.getLocation()) == null) { msg(sender, "&cChunk deja libre."); return true; }
                fm.unclaim(p.getLocation().getChunk());
                msg(sender, "&aChunk libere.");
            }
            case "forceclaim" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cJoueur uniquement."); return true; }
                if (args.length < 2) { msg(sender, "&cUsage : /fadmin forceclaim <faction>"); return true; }
                Faction f = fm.getByName(args[1]);
                if (f == null) { msg(sender, "&cFaction introuvable."); return true; }
                fm.claim(f, p.getLocation().getChunk());
                msg(sender, "&aChunk attribue a &f" + f.getName() + "&a.");
            }
            default -> msg(sender, "&cSous-commande inconnue.");
        }
        return true;
    }

    private Double parse(String s) {
        try {
            double d = Double.parseDouble(s);
            return Double.isNaN(d) || Double.isInfinite(d) ? null : d;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
