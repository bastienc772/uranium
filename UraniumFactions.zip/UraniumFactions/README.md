# UraniumFactions (Paper 1.21.4, Java 21)

Compiler : `mvn clean package` -> `target/UraniumFactions.jar` dans `plugins/`.
Prerequis serveur : Vault + un plugin d'economie (ex: EssentialsX) pour la banque.

Joueurs : /f (menu GUI), create, disband, invite, join, leave, kick, promote, demote,
claim, unclaim, sethome, home, deposit, withdraw, top, info
Admin : /fadmin disband|setpower|setbank|unclaim|forceclaim
Permissions : uraniumfactions.admin, uraniumfactions.bypass
